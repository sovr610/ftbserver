package com.pad.production;

public class Driver {
	private static Program prgm;
	
	public static void main(String[] args)
	{
		prgm = new Program();
		prgm.consoleMain();
	}
}
